# Build + install + first test

## 1 Files created (under src/phonepilot)
settings.gradle.kts, build.gradle.kts, gradle.properties, app/build.gradle.kts, AndroidManifest.xml, res/xml/accessibility_config.xml, MainActivity.kt (chat+mic+send+status+STOP+history+setup+settings), PilotAccessibilityService.kt, ai/{AIService, AiAction, OpenAiBrain}, core/{ScreenObserver, ActionExecutor, ActionValidator, TaskManager, PermissionManager, SettingsManager, ConversationManager}, voice/VoiceInput.kt

## 2 Build APK
- Install Android Studio Hedgehog+, JDK 17, SDK 34.
- Copy src/phonepilot to your PC (it is the Gradle root).
- Open folder in Android Studio → let Gradle sync → Run ▶ on emulator OR Build > Generate App APKs / ./gradlew :app:assembleDebug.
- Output: app/build/outputs/apk/debug/app-debug.apk

## 3 Install
- adb install app-debug.apk, or copy APK to phone and tap it (allow unknown apps).

## 4 Permissions
INTERNET, RECORD_AUDIO, POST_NOTIFICATIONS, ACCESS/CHANGE_WIFI_STATE, QUERY_ALL_PACKAGES, READ_MEDIA_IMAGES + AccessibilityService binding. No root. Never bypasses lock/passwords.

## 5 Enable Accessibility
PhonePilot → Setup tab → Open Accessibility Settings → Accessibility → PhonePilot → ON → Allow. Return: shows ✓.

## 6 AI key
Settings tab → API key + Base URL (default https://api.openai.com/v1) + Model (gpt-4o-mini) → Save. Leave blank = offline rule-based brain (open/search/wifi/back/screenshot only). Swap Base URL to any OpenAI-compatible local server later.

## 7 First test
Chat tab → type "Open Settings." → Send → watch status: Opening Settings… → Observing… → Finish. Then try "Turn Wi-Fi on.", "Take a screenshot.", "Go back.", "Open Chrome and search for YouTube."
