# PhonePilot — AI personal phone agent (Android)

Kotlin + Jetpack Compose. Modular agent loop: UNDERSTAND → OBSERVE → PLAN → EXECUTE ONE → OBSERVE → VERIFY.

## Structure
See SPEC.md. Key modules: MainActivity, PilotAccessibilityService, ai/AIService, core/{ScreenObserver,ActionExecutor,ActionValidator,TaskManager,ConversationManager,PermissionManager,SettingsManager}, voice/VoiceInput.

## Build
1. Install Android Studio Hedgehog+ / JDK 17 / SDK 34.
2. Open `src/phonepilot` as project (contains settings.gradle.kts).
3. Add AI key in app Settings screen (no hardcode) or adb: settings put via DataStore UI.
4. Run ▶ or `./gradlew :app:assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions
POST_NOTIFICATIONS, RECORD_AUDIO, BIND_ACCESSIBILITY_SERVICE (PilotAccessibilityService), QUERY_ALL_PACKAGES (optional, for app launch), ACCESS_WIFI_STATE/CHANGE_WIFI_STATE, READ_MEDIA_IMAGES (screenshot save).
No root, no bypass of lock/auth — never touches passwords.
