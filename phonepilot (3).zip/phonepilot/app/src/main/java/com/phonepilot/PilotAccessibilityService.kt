package com.phonepilot

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import com.phonepilot.ai.ScreenState
import com.phonepilot.core.ScreenObserver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class PilotAccessibilityService : AccessibilityService() {
  var currentPackage: String = ""
  private var lastPush = 0L

  override fun onServiceConnected() { INST = this }

  override fun onAccessibilityEvent(e: AccessibilityEvent?) {
    e?.packageName?.toString()?.let { if (it.isNotEmpty()) currentPackage = it }
    val now = System.currentTimeMillis()
    if (now - lastPush < 900) return
    lastPush = now
    try {
      _live.value = ScreenObserver.snapshot(this)
    } catch (_: Exception) { }
  }

  override fun onInterrupt() {}

  override fun onDestroy() {
    if (INST == this) INST = null
    super.onDestroy()
  }

  fun takeScreenshotApi30(onDone: (Boolean) -> Unit) {
    if (Build.VERSION.SDK_INT < 30) { onDone(false); return }
    try {
      takeScreenshot(
        android.view.Display.DEFAULT_DISPLAY,
        mainExecutor,
        object : TakeScreenshotCallback {
          override fun onSuccess(result: ScreenshotResult) { onDone(true) }
          override fun onFailure(errorCode: Int) { onDone(false) }
        }
      )
    } catch (_: Exception) { onDone(false) }
  }

  companion object {
    private var INST: PilotAccessibilityService? = null
    private val _live = MutableStateFlow<ScreenState?>(null)
    val live: StateFlow<ScreenState?> = _live
    fun instance() = INST
    fun currentPackage() = INST?.currentPackage ?: ""
    fun pushNow() {
      try { INST?.let { _live.value = ScreenObserver.snapshot(it) } } catch (_: Exception) {}
    }
  }
}
