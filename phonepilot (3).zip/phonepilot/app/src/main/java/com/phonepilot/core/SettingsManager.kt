package com.phonepilot.core

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.store by preferencesDataStore("phonepilot")

object SettingsManager {
  private val PROVIDER = stringPreferencesKey("provider")
  private val KEY = stringPreferencesKey("api_key")
  private val BASE = stringPreferencesKey("base_url")
  private val MODEL = stringPreferencesKey("model")
  private val CONFIRM = booleanPreferencesKey("confirm_sensitive")
  private val DEBUG = booleanPreferencesKey("debug_log")
  private val MAXSTEPS = stringPreferencesKey("max_steps")
  private val VOICE_LANG = stringPreferencesKey("voice_lang")

  val PROVIDERS = listOf("openai" to "OpenAI", "gemini" to "Gemini", "anthropic" to "Anthropic", "openrouter" to "OpenRouter", "rule" to "Offline rules")

  data class Cfg(
    val provider: String = "openai",
    val key: String = "",
    val base: String = "https://api.openai.com/v1",
    val model: String = "gpt-4o-mini",
    val confirm: Boolean = true,
    val debug: Boolean = false,
    val maxSteps: Int = 25,
    val voiceLang: String = "en-US"
  )

  fun flow(ctx: Context): Flow<Cfg> = ctx.store.data.map { p ->
    Cfg(
      p[PROVIDER] ?: "openai",
      p[KEY] ?: "",
      p[BASE] ?: defaultBase(p[PROVIDER] ?: "openai"),
      p[MODEL] ?: "gpt-4o-mini",
      p[CONFIRM] ?: true,
      p[DEBUG] ?: false,
      (p[MAXSTEPS]?.toIntOrNull() ?: 25).coerceIn(3, 60),
      p[VOICE_LANG] ?: "en-US"
    )
  }

  fun defaultBase(provider: String) = when (provider) {
    "gemini" -> "https://generativelanguage.googleapis.com/v1beta/openai"
    "anthropic" -> "https://api.anthropic.com/v1/openai"
    "openrouter" -> "https://openrouter.ai/api/v1"
    else -> "https://api.openai.com/v1"
  }

  suspend fun save(ctx: Context, c: Cfg) {
    ctx.store.edit {
      it[PROVIDER] = c.provider; it[KEY] = c.key; it[BASE] = c.base
      it[MODEL] = c.model; it[CONFIRM] = c.confirm; it[DEBUG] = c.debug
      it[MAXSTEPS] = c.maxSteps.toString(); it[VOICE_LANG] = c.voiceLang
    }
  }
}
