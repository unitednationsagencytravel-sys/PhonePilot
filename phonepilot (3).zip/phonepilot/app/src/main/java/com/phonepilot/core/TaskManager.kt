package com.phonepilot.core

import com.phonepilot.PilotAccessibilityService
import com.phonepilot.ai.AgentContext
import com.phonepilot.ai.AiAction
import com.phonepilot.ai.AIProvider
import com.phonepilot.ai.ScreenState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class TaskManager(
  val brain: AIProvider,
  private val confirmEnabled: () -> Boolean = { true },
  private val visionPermitted: () -> Boolean = { false },
  private val maxSteps: () -> Int = { 25 },
  private val debugEnabled: () -> Boolean = { false },
  private val captureScreenshotB64: suspend () -> String? = { null }
) {
  private var job: Job? = null
  private val stopFlag = AtomicBoolean(false)
  private val _status = MutableStateFlow("Idle")
  val status: StateFlow<String> = _status
  private val _history = MutableStateFlow<List<String>>(emptyList())
  val history: StateFlow<List<String>> = _history
  val pendingConfirm = MutableStateFlow<AiAction?>(null)
  val debug = MutableStateFlow("")
  private val screenHistory = ScreenHistory(3)
  var lastScreen: ScreenState? = null
    private set
  var lastVisionUsed: Boolean = false
    private set
  var lastRequestInfo: String = ""
    private set
  private var lastShotStep = -10

  fun stop() {
    stopFlag.set(true)
    pendingConfirm.value = null
    job?.cancel()
    job = null
    _status.value = "Stopped."
  }

  fun isRunning() = job?.isActive == true && !stopFlag.get()

  fun run(scope: CoroutineScope, command: String, confirmGate: suspend (AiAction) -> Boolean) {
    job?.cancel()
    stopFlag.set(false)
    _history.value = emptyList()
    debug.value = ""
    lastVisionUsed = false
    lastRequestInfo = ""
    lastShotStep = -10
    job = scope.launch {
      val hist = mutableListOf<String>()
      var fails = 0
      _status.value = "Understanding: $command"
      delay(300)
      val steps = maxSteps().coerceIn(3, 60)
      repeat(steps) { step ->
        ensureActive()
        if (stopFlag.get()) return@launch
        val svc = PilotAccessibilityService.instance()
        if (svc == null) {
          _status.value = "Waiting for Accessibility Service… (enable it in Setup)"
          delay(1200); return@repeat
        }
        _status.value = "Observing screen…"
        delay(700)
        if (stopFlag.get()) return@launch
        val screen = try { ScreenObserver.snapshot(svc) } catch (_: Exception) { null }
        if (screen == null) { delay(800); return@repeat }
        lastScreen = screen
        screenHistory.push(screen)
        if (ActionValidator.isAuthScreen(screen)) {
          _status.value = "Paused: screen needs your PIN / password / biometric. Do it yourself, then re-send the command."
          _history.value = hist.toList()
          return@launch
        }
        val canVision = visionPermitted() && brain.supportsVision
        var shotB64: String? = null
        var visionThisStep = false
        if (canVision && shouldCapture(screen, fails, step)) {
          _status.value = "Capturing screen for vision…"
          shotB64 = try { captureScreenshotB64() } catch (_: Exception) { null }
          lastVisionUsed = shotB64 != null
          visionThisStep = shotB64 != null
          if (shotB64 != null) lastShotStep = step
        } else {
          lastVisionUsed = false
        }
        if (stopFlag.get()) return@launch
        _status.value = "Planning next action…"
        val action = try {
          brain.nextAction(AgentContext(command, screen, hist.toList(), canVision, fails, shotB64))
        } catch (e: Exception) {
          _status.value = "AI error: ${e.message}"
          return@launch
        }
        lastRequestInfo = "provider=${brain.id} vision=${if (visionThisStep) "image-sent" else "a11y-only"} els=${screen.elements.size}"
        if (stopFlag.get()) return@launch
        if (debugEnabled()) debug.value = "step=$step/$steps action=${action.javaClass.simpleName} pkg=${screen.packageName} els=${screen.elements.size} vision=$visionThisStep fails=$fails"
        if (action is AiAction.Finish) {
          _status.value = action.message
          _history.value = hist.toList()
          return@launch
        }
        if (action is AiAction.Ask) {
          _status.value = "Needs you: ${action.question}"
          _history.value = hist.toList()
          return@launch
        }
        ActionValidator.validate(action, screen, visionThisStep)?.let { err ->
          fails++
          _status.value = err
          hist.add("rejected: $err")
          _history.value = hist.toList()
          delay(700)
          if (fails > 4) { _status.value = "Stopped safely: cannot ground action. $err"; return@launch }
          return@repeat
        }
        if (ActionValidator.needsConfirmation(command, action, confirmEnabled())) {
          _status.value = "Confirm: ${describe(action)}"
          pendingConfirm.value = action
          while (pendingConfirm.value != null) {
            ensureActive()
            if (stopFlag.get()) return@launch
            delay(250)
          }
        }
        if (stopFlag.get()) return@launch
        if (!confirmGate(action)) { _status.value = "Stopped."; return@launch }
        _status.value = describe(action)
        screenHistory.lastAction = describe(action)
        screenHistory.lastDecision = action.toString().take(300)
        val before = screen
        val result = try { ActionExecutor.execute(svc, screen, action) } catch (e: Exception) {
          ActionResult(false, "exec error: ${e.message}")
        }
        if (stopFlag.get()) return@launch
        var res = result
        if (!res.ok && res.message.startsWith("NEEDS_COORD:")) {
          if (visionThisStep && shotB64 != null) {
            val parts = res.message.removePrefix("NEEDS_COORD:").split(",")
            val x = parts.getOrNull(0)?.toIntOrNull() ?: -1
            val y = parts.getOrNull(1)?.toIntOrNull() ?: -1
            res = ActionExecutor.execute(svc, screen, AiAction.TapCoordinate(x, y, "a11y fallback, vision attached", 0.7))
          } else {
            res = ActionResult(false, "element not tappable via accessibility; vision image " + if (!canVision) "unavailable (grant capture + use vision model)" else "not captured this step — will capture next")
          }
        }
        _status.value = "Waiting for UI…"
        delay(1100)
        if (stopFlag.get()) return@launch
        val after = try { ScreenObserver.snapshot(svc) } catch (_: Exception) { null }
        if (after != null) {
          lastScreen = after
          screenHistory.push(after)
        }
        val verified = verify(command, action, before, after, res)
        hist.add("${describe(action)} → ${res.message}${if (verified.startsWith("UNVERIFIED")) " ($verified)" else ""}" + if (visionThisStep) " [vision]" else "")
        _history.value = hist.toList()
        screenHistory.lastResult = res.message + " | " + verified
        if (!res.ok) {
          fails++
          _status.value = recoverHint(command, action, res.message)
          delay(900)
          if (fails > 5) { _status.value = "Stopped safely after $fails failures: ${res.message}"; return@launch }
        } else {
          if (verified.startsWith("OK") || verified.startsWith("UNVERIFIED")) fails = 0
          else { fails++; if (fails > 5) { _status.value = "Stopped: action did not change screen. $verified"; return@launch } }
          if (isGoalDone(command, action, after)) {
            _status.value = "Done: ${describe(action)} verified."
            return@launch
          }
        }
      }
      _status.value = "Finished (step limit $steps)."
    }
  }

  private fun shouldCapture(screen: ScreenState, fails: Int, step: Int): Boolean {
    if (step - lastShotStep < 2) return false
    if (fails > 0) return true
    val tappable = screen.elements.count { it.clickable && (it.text.isNotEmpty() || it.contentDescription.isNotEmpty()) }
    if (screen.elements.isNotEmpty() && tappable == 0) return true
    return false
  }

  suspend fun confirmAction(ok: Boolean) {
    if (!ok) { stop(); return }
    pendingConfirm.value = null
  }

  private fun verify(cmd: String, a: AiAction, before: ScreenState, after: ScreenState?, res: ActionResult): String {
    if (after == null) return "UNVERIFIED: no screen"
    if (!res.ok) return "FAILED: ${res.message}"
    val c = cmd.lowercase()
    if (a is AiAction.LaunchApp && c.startsWith("open ")) {
      val want = c.removePrefix("open ").split(" and ", " > ").first().trim()
      if (after.packageName.contains(want.replace(" ", ""), true) || after.appName.contains(want, true)) return "OK: now in ${after.appName}"
      return "UNVERIFIED: launched but active=${after.appName} (${after.packageName})"
    }
    if (a is AiAction.Type) {
      if (after.screenText.contains(a.text, true)) return "OK: text visible"
      return "UNVERIFIED: typed, cannot confirm text on screen"
    }
    if (a is AiAction.TapElement && ("send" in c)) return "UNVERIFIED: tap done — check conversation for the sent message"
    if (before.packageName != after.packageName) return "OK: moved ${before.packageName} → ${after.packageName}"
    if (before.screenText != after.screenText || before.elements.size != after.elements.size) return "OK: screen changed"
    return "UNVERIFIED: screen looks unchanged"
  }

  private fun recoverHint(cmd: String, a: AiAction, msg: String): String {
    return when {
      "not found" in msg || "Unknown element" in msg ->
        "Re-observing… ($msg). Trying another interpretation next."
      "vision image unavailable" in msg || "vision off" in msg ->
        "Accessibility can't see it and no vision image yet. Capturing screenshot next step."
      else -> "That didn't work ($msg). Re-observing before retrying."
    }
  }

  private fun isGoalDone(cmd: String, a: AiAction, after: ScreenState?): Boolean {
    if (after == null) return false
    val c = cmd.lowercase().trim()
    if (c.startsWith("open ") && !c.contains(" and ") && a is AiAction.LaunchApp) {
      val want = c.removePrefix("open ").trim().trimEnd('.')
      if (want in listOf("settings") && after.packageName.contains("settings", true)) return true
      if (after.appName.contains(want, true) || after.packageName.contains(want.replace(" ", ""), true)) return true
    }
    return false
  }

  fun describe(a: AiAction) = when (a) {
    is AiAction.TapElement -> "Tapping \"${a.targetId}\"…"
    is AiAction.TapCoordinate -> "Tapping (${a.x},${a.y})…"
    is AiAction.LongPress -> "Long-pressing…"
    is AiAction.DoubleTap -> "Double-tapping…"
    is AiAction.Type -> "Typing message…"
    is AiAction.ClearText -> "Clearing text…"
    is AiAction.Paste -> "Pasting…"
    is AiAction.Swipe -> "Swiping ${a.direction}…"
    is AiAction.Scroll -> "Scrolling ${a.direction}…"
    is AiAction.Drag -> "Dragging…"
    is AiAction.Back -> "Going back…"
    is AiAction.Home -> "Going home…"
    is AiAction.RecentApps -> "Opening recents…"
    is AiAction.LaunchApp -> "Opening ${a.query}…"
    is AiAction.SwitchApp -> "Switching app…"
    is AiAction.OpenNotifications -> "Opening notifications…"
    is AiAction.OpenSettings -> "Opening Settings…"
    is AiAction.Wifi -> "Turning Wi-Fi ${if (a.on) "on" else "off"}…"
    is AiAction.Screenshot -> "Taking screenshot…"
    is AiAction.Wait -> "Waiting for screen…"
    is AiAction.Copy -> "Copying…"
    is AiAction.Share -> "Sharing…"
    is AiAction.PressKey -> "Pressing ${a.code}…"
    is AiAction.Finish -> a.message
    is AiAction.Ask -> "Needs you: ${a.question}"
  }
}
