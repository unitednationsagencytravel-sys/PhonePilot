package com.phonepilot

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.phonepilot.ai.buildProvider
import com.phonepilot.core.ConversationManager
import com.phonepilot.core.Msg
import com.phonepilot.core.PermissionManager
import com.phonepilot.core.SettingsManager
import com.phonepilot.core.TaskManager
import com.phonepilot.vision.ScreenshotManager
import com.phonepilot.voice.VoiceInput
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent { App() }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
  MaterialTheme {
    var tab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val cfg by SettingsManager.flow(ctx).collectAsState(initial = SettingsManager.Cfg())
    val shotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
      ScreenshotManager.onPermissionResult(ctx, r.resultCode, r.data)
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val tm = remember(cfg.provider, cfg.key, cfg.base, cfg.model, cfg.confirm, cfg.maxSteps, cfg.debug, cfg.voiceLang) {
      TaskManager(
        buildProvider(cfg.provider, { cfg.key.ifBlank { null } }, { cfg.base }, { cfg.model }),
        confirmEnabled = { cfg.confirm },
        visionPermitted = { ScreenshotManager.hasPermission },
        maxSteps = { cfg.maxSteps },
        debugEnabled = { cfg.debug },
        captureScreenshotB64 = { ScreenshotManager.captureJpegB64(ctx) }
      )
    }
    val status by tm.status.collectAsState()
    val hist by tm.history.collectAsState()
    val dbg by tm.debug.collectAsState()
    var input by remember { mutableStateOf("") }
    var log by remember { mutableStateOf(listOf<Msg>()) }
    val confirm by tm.pendingConfirm.collectAsState()
    val conv = remember { ConversationManager() }

    Scaffold(
      topBar = {
        TopAppBar(
          title = { Text("PhonePilot" + if (tm.isRunning()) " — $status" else "") },
          actions = { IconButton(onClick = { tab = 2 }) { Icon(Icons.Default.Settings, null) } }
        )
      },
      bottomBar = {
        NavigationBar {
          NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Chat, null) }, label = { Text("Chat") })
          NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Security, null) }, label = { Text("Setup") })
          NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("AI") })
          NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Terminal, null) }, label = { Text("Debug") })
        }
      }
    ) { pad ->
      Box(Modifier.padding(pad)) {
        when (tab) {
          0 -> Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text(status, style = MaterialTheme.typography.labelLarge)
            if (tm.isRunning())
              Button(
                onClick = { tm.stop() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth()
              ) { Text("STOP") }
            LazyColumn(Modifier.weight(1f)) {
              items(log) { Text((if (it.fromMe) "You: " else "Pilot: ") + it.text, modifier = Modifier.padding(4.dp)) }
              items(hist) { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            }
            confirm?.let { a ->
              AlertDialog(
                onDismissRequest = {},
                title = { Text("Confirm sensitive action") },
                text = { Text(tm.describe(a) + "\nThis may send/post/change something. Proceed?") },
                confirmButton = { Button(onClick = { scope.launch { tm.confirmAction(true) } }) { Text("Allow") } },
                dismissButton = { Button(onClick = { tm.stop() }) { Text("Deny") } }
              )
            }
            Row {
              OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Try: Open Settings…") })
              IconButton(onClick = {
                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                try { VoiceInput(ctx).listen(cfg.voiceLang) { input = it } } catch (_: Exception) {}
              }) { Icon(Icons.Default.Mic, null) }
              Button(onClick = {
                val c = input.trim()
                if (c.isEmpty()) return@Button
                input = ""
                log = log + Msg(true, c)
                conv.add(Msg(true, c))
                tm.run(scope, c) { true }
              }) { Text("Send") }
            }
          }
          1 -> SetupScreen(onShot = { shotLauncher.launch(ScreenshotManager.createRequestIntent(ctx)) })
          2 -> SettingsScreen(cfg)
          else -> DebugScreen(tm, dbg)
        }
      }
    }
  }
}

@Composable
fun SetupScreen(onShot: () -> Unit) {
  val ctx = LocalContext.current
  LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    item {
      val ok = PermissionManager.isAccessibilityOn(ctx)
      Text(if (ok) "✓ Accessibility enabled" else "1. Accessibility: enable PhonePilot", style = MaterialTheme.typography.titleMedium)
      Button(onClick = { ctx.startActivity(PermissionManager.accessibilityIntent()) }) { Text("Open Accessibility Settings") }
    }
    item {
      val missing = PermissionManager.missingPermissions(ctx)
      Text(if (missing.isEmpty()) "✓ Mic + Notifications granted" else "2. Grant: " + missing.joinToString())
    }
    item {
      Text(if (ScreenshotManager.hasPermission) "✓ Screen capture granted (vision fallback ready)" else "3. Screen capture (optional, explicit consent — needed for icon-only buttons)")
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onShot) { Text(if (ScreenshotManager.hasPermission) "Re-grant" else "Grant screen capture") }
        if (ScreenshotManager.hasPermission) Button(onClick = { ScreenshotManager.revoke(ctx) }) { Text("Revoke") }
      }
      if (ScreenshotManager.lastError.isNotEmpty()) Text("Capture: ${ScreenshotManager.lastError}", style = MaterialTheme.typography.bodySmall)
    }
    item {
      Text("4. AI key in AI tab. 5. POCO/Xiaomi: Settings → Apps → PhonePilot → Autostart ON, Battery saver → No restrictions, Notifications ON, lock it in Recents. No root, no PC needed.", style = MaterialTheme.typography.bodySmall)
      Text("Vision images are captured ONLY when accessibility text is insufficient (max every 2 steps, 540px JPEG) and sent ONLY to your configured endpoint when the model supports it — otherwise accessibility-only with an explicit note.", style = MaterialTheme.typography.bodySmall)
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(cfg: SettingsManager.Cfg) {
  val ctx = LocalContext.current
  val scope = rememberCoroutineScope()
  var provider by remember(cfg) { mutableStateOf(cfg.provider) }
  var key by remember(cfg) { mutableStateOf(cfg.key) }
  var base by remember(cfg) { mutableStateOf(cfg.base) }
  var model by remember(cfg) { mutableStateOf(cfg.model) }
  var confirm by remember(cfg) { mutableStateOf(cfg.confirm) }
  var debug by remember(cfg) { mutableStateOf(cfg.debug) }
  var maxSteps by remember(cfg) { mutableStateOf(cfg.maxSteps.toString()) }
  var voiceLang by remember(cfg) { mutableStateOf(cfg.voiceLang) }
  var expanded by remember { mutableStateOf(false) }
  LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    item { Text("AI provider (modular — key never hard-coded, sent only to your endpoint)", style = MaterialTheme.typography.titleSmall) }
    item {
      ExposedDropdownMenuBox(expanded, { expanded = it }) {
        OutlinedTextField(
          SettingsManager.PROVIDERS.firstOrNull { it.first == provider }?.second ?: provider,
          {}, readOnly = true, label = { Text("Provider") }, modifier = Modifier.fillMaxWidth().menuAnchor(),
          trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
        )
        ExposedDropdownMenu(expanded, { expanded = false }) {
          SettingsManager.PROVIDERS.forEach { (id, name) ->
            DropdownMenuItem({ Text(name + if (id == "rule") " — offline" else "") }, onClick = {
              provider = id
              base = SettingsManager.defaultBase(id)
              expanded = false
            })
          }
        }
      }
    }
    item { OutlinedTextField(key, { key = it }, label = { Text("API key (blank = offline rules)") }, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation(), singleLine = true) }
    item { OutlinedTextField(base, { base = it }, label = { Text("Base URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
    item { OutlinedTextField(model, { model = it }, label = { Text("Model (must be vision-capable for screenshots)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
    item { Row { Checkbox(confirm, { confirm = it }); Text("Confirm before send/delete/purchase/post") } }
    item { Row { Checkbox(debug, { debug = it }); Text("Detailed logging (Debug tab)") } }
    item { OutlinedTextField(maxSteps, { maxSteps = it.filter(Char::isDigit).take(2) }, label = { Text("Max steps (3-60, actually enforced)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
    item { OutlinedTextField(voiceLang, { voiceLang = it }, label = { Text("Voice language (e.g. en-US)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
    item {
      Button(onClick = {
        scope.launch {
          SettingsManager.save(ctx, SettingsManager.Cfg(provider, key, base, model, confirm, debug, maxSteps.toIntOrNull() ?: 25, voiceLang.ifBlank { "en-US" }))
        }
      }) { Text("Save") }
    }
    item { Text("Every setting is live: provider+model+endpoint route the next task, max-steps caps it, confirm gates sensitive taps, debug fills the Debug tab, voice language goes to the recognizer.", style = MaterialTheme.typography.bodySmall) }
  }
}

@Composable
fun DebugScreen(tm: TaskManager, dbg: String) {
  val s = tm.lastScreen
  val visionLine = when {
    tm.lastVisionUsed -> "Vision: image SENT with last request (${tm.lastRequestInfo})"
    ScreenshotManager.hasPermission && tm.lastRequestInfo.contains("a11y-only") -> "Vision: permission granted, model " + if (tm.lastRequestInfo.startsWith("provider=rule")) "has no vision (offline rules) — a11y only" else "did not need image this step"
    ScreenshotManager.hasPermission -> "Vision: ready (capture ok=${ScreenshotManager.lastCaptureOk})"
    else -> "Vision: unavailable — " + (ScreenshotManager.lastError.ifEmpty { "grant screen capture in Setup" })
  }
  LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    item { Text("Task: ${tm.status.collectAsState().value}", style = MaterialTheme.typography.titleMedium) }
    item { Text("Step detail: ${dbg.ifEmpty { "(enable Detailed logging in AI tab)" }}", style = MaterialTheme.typography.bodySmall) }
    item { Text(visionLine, style = MaterialTheme.typography.bodySmall) }
    item { Text("Request: ${tm.lastRequestInfo.ifEmpty { "—"}}", style = MaterialTheme.typography.bodySmall) }
    item { Text("App: ${s?.appName ?: "?"} (${s?.packageName ?: "?"}) • ${s?.elements?.size ?: 0} elements", style = MaterialTheme.typography.bodySmall) }
    item { Text("Screen text: ${(s?.screenText ?: "—").take(800)}", style = MaterialTheme.typography.bodySmall) }
    val hist by tm.history.collectAsState()
    items(hist) { Text("• $it", style = MaterialTheme.typography.bodySmall) }
    s?.elements?.take(40)?.forEach { e ->
      item { Text("${e.id} ${if (e.clickable) "[tap]" else ""}${if (e.editable) "[edit]" else ""} \"${e.text.ifEmpty { e.contentDescription }.take(50)}\" @${e.bounds.cx},${e.bounds.cy}", style = MaterialTheme.typography.bodySmall) }
    }
  }
}
