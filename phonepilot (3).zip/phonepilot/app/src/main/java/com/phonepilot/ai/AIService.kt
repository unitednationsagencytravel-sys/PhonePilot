package com.phonepilot.ai

fun guessPackage(name: String): String? {
  val n = name.lowercase().trim()
  return mapOf(
    "whatsapp" to "com.whatsapp",
    "chrome" to "com.android.chrome",
    "youtube" to "com.google.android.youtube",
    "settings" to "com.android.settings",
    "gmail" to "com.google.android.gm",
    "maps" to "com.google.android.apps.maps",
    "discord" to "com.discord",
    "telegram" to "org.telegram.messenger"
  )[n]
}
