package com.phonepilot.vision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder

class ScreenCaptureService : Service() {
  override fun onCreate() {
    super.onCreate()
    ensureChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_START -> {
        val code = intent.getIntExtra(EXTRA_CODE, -999)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
          intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
          @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        if (code != -999 && data != null) {
          try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
            ScreenshotManager.attachProjection(proj)
          } catch (_: Exception) { stopSelf() }
        }
        startFg()
      }
      ACTION_STOP -> {
        ScreenshotManager.detachProjection()
        stopSelf()
      }
    }
    return START_STICKY
  }

  private fun startFg() {
    val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    val notif: Notification = if (Build.VERSION.SDK_INT >= 26) {
      Notification.Builder(this, CH).setContentTitle("PhonePilot screen capture").setContentText("Ready for agent vision when you ask it to look.").setSmallIcon(android.R.drawable.ic_menu_camera).build()
    } else {
      @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("PhonePilot screen capture").setSmallIcon(android.R.drawable.ic_menu_camera).build()
    }
    try {
      if (Build.VERSION.SDK_INT >= 29) {
        startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
      } else {
        startForeground(NOTIF_ID, notif)
      }
    } catch (_: Exception) { nm.notify(NOTIF_ID, notif) }
  }

  private fun ensureChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
      try {
        nm.createNotificationChannel(NotificationChannel(CH, "Screen capture", NotificationManager.IMPORTANCE_MIN))
      } catch (_: Exception) {}
    }
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onTaskRemoved(rootIntent: Intent?) {
    ScreenshotManager.detachProjection()
    stopSelf()
  }

  companion object {
    const val ACTION_START = "pp.capture.START"
    const val ACTION_STOP = "pp.capture.STOP"
    const val EXTRA_CODE = "code"
    const val EXTRA_DATA = "data"
    const val CH = "pp_capture"
    const val NOTIF_ID = 41

    fun startIntent(ctx: android.content.Context, code: Int, data: Intent): Intent {
      return Intent(ctx, ScreenCaptureService::class.java).setAction(ACTION_START)
        .putExtra(EXTRA_CODE, code).putExtra(EXTRA_DATA, data)
    }
  }
}

fun MediaProjection?.safeStop() {
  try { this?.stop() } catch (_: Exception) {}
}
