package com.phonepilot.vision

import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream

object ImageCodec {
  fun toJpegB64(src: Bitmap, maxW: Int = 768, quality: Int = 60): String {
    val w = src.width
    val h = src.height
    val bmp = if (w > maxW) {
      val scale = maxW.toFloat() / w
      Bitmap.createScaledBitmap(src, maxW, (h * scale).toInt().coerceAtLeast(1), true)
    } else src
    val out = ByteArrayOutputStream()
    bmp.toCompressFormatJpeg(out, quality)
    val bytes = out.toByteArray()
    try { out.close() } catch (_: Exception) {}
    if (bmp !== src) try { bmp.recycle() } catch (_: Exception) {}
    return Base64.encodeToString(bytes, Base64.NO_WRAP)
  }

  private fun Bitmap.toCompressFormatJpeg(out: ByteArrayOutputStream, q: Int) {
    compress(Bitmap.CompressFormat.JPEG, q, out)
  }
}
