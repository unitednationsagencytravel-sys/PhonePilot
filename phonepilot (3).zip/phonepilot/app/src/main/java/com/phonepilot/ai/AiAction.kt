package com.phonepilot.ai

import kotlinx.serialization.json.*

sealed interface AiAction {
  data class TapElement(val targetId: String, val reason: String = "", val confidence: Double = 1.0) : AiAction
  data class TapCoordinate(val x: Int, val y: Int, val reason: String = "", val confidence: Double = 1.0) : AiAction
  data class LongPress(val targetId: String? = null, val x: Int? = null, val y: Int? = null) : AiAction
  data class DoubleTap(val targetId: String? = null, val x: Int? = null, val y: Int? = null) : AiAction
  data class Type(val text: String, val targetId: String? = null) : AiAction
  data class ClearText(val targetId: String? = null) : AiAction
  data class Paste(val targetId: String? = null) : AiAction
  data class Swipe(val direction: String, val x1: Int? = null, val y1: Int? = null, val x2: Int? = null, val y2: Int? = null) : AiAction
  data class Scroll(val direction: String, val amount: Int = 650, val targetId: String? = null) : AiAction
  data class Drag(val x1: Int, val y1: Int, val x2: Int, val y2: Int) : AiAction
  data object Back : AiAction
  data object Home : AiAction
  data object RecentApps : AiAction
  data class LaunchApp(val query: String) : AiAction
  data class SwitchApp(val packageName: String) : AiAction
  data object OpenNotifications : AiAction
  data object OpenSettings : AiAction
  data class Wifi(val on: Boolean) : AiAction
  data object Screenshot : AiAction
  data class Wait(val ms: Int) : AiAction
  data object Copy : AiAction
  data object Share : AiAction
  data class PressKey(val code: String) : AiAction
  data class Finish(val message: String, val success: Boolean = true) : AiAction
  data class Ask(val question: String) : AiAction
}

fun parseAiAction(json: String): AiAction {
  val o = try { Json.parseToJsonElement(json).jsonObject } catch (_: Exception) { return AiAction.Finish("Done.") }
  fun s(k: String) = (o[k] as? JsonPrimitive)?.contentOrNull
  fun i(k: String) = (o[k] as? JsonPrimitive)?.intOrNull
  fun d(k: String) = (o[k] as? JsonPrimitive)?.doubleOrNull ?: 1.0
  return when (s("action")) {
    "tap_element", "click" -> AiAction.TapElement(s("targetId") ?: s("target") ?: "", s("reason") ?: "", d("confidence"))
    "tap_coordinate" -> AiAction.TapCoordinate(i("x") ?: -1, i("y") ?: -1, s("reason") ?: "", d("confidence"))
    "long_press" -> AiAction.LongPress(s("targetId"), i("x"), i("y"))
    "double_tap" -> AiAction.DoubleTap(s("targetId"), i("x"), i("y"))
    "type" -> AiAction.Type(s("text") ?: "", s("targetId") ?: s("target"))
    "clear_text" -> AiAction.ClearText(s("targetId"))
    "paste" -> AiAction.Paste(s("targetId"))
    "swipe" -> AiAction.Swipe(s("direction") ?: "up", i("x1"), i("y1"), i("x2"), i("y2"))
    "scroll" -> AiAction.Scroll(s("direction") ?: "down", i("amount") ?: 650, s("targetId"))
    "drag" -> AiAction.Drag(i("x1") ?: -1, i("y1") ?: -1, i("x2") ?: -1, i("y2") ?: -1)
    "back" -> AiAction.Back
    "home" -> AiAction.Home
    "recent_apps" -> AiAction.RecentApps
    "launch", "launch_app" -> AiAction.LaunchApp(s("package") ?: s("query") ?: "")
    "switch_app" -> AiAction.SwitchApp(s("packageName") ?: "")
    "open_notifications" -> AiAction.OpenNotifications
    "open_settings" -> AiAction.OpenSettings
    "wifi" -> AiAction.Wifi((o["on"] as? JsonPrimitive)?.booleanOrNull ?: true)
    "screenshot" -> AiAction.Screenshot
    "wait" -> AiAction.Wait(i("ms") ?: 800)
    "copy" -> AiAction.Copy
    "share" -> AiAction.Share
    "press_key" -> AiAction.PressKey(s("code") ?: "enter")
    "ask", "ask_user" -> AiAction.Ask(s("question") ?: "")
    else -> AiAction.Finish(s("message") ?: "Done.", s("action") != "fail")
  }
}
