package com.phonepilot.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*

interface AIProvider {
  val id: String
  val displayName: String
  val supportsVision: Boolean
  suspend fun nextAction(ctx: AgentContext): AiAction
}

class RuleBasedBrain : AIProvider {
  override val id = "rule"
  override val displayName = "On-device rules (no vision)"
  override val supportsVision = false
  override suspend fun nextAction(ctx: AgentContext): AiAction {
    val cmd = ctx.command.lowercase()
    val scr = ctx.screen
    fun find(vararg keys: String) = scr.elements.firstOrNull { e ->
      keys.any { k -> e.text.contains(k, true) || e.contentDescription.contains(k, true) }
    }
    if (cmd.startsWith("open ")) {
      val name = cmd.removePrefix("open ").split(" and ", " > ").first().trim()
      if (name.contains("setting")) return AiAction.OpenSettings
      if (name.contains("notification")) return AiAction.OpenNotifications
      if (scr.appName.contains(name, true) || scr.packageName.contains(name.replace(" ", ""), true))
        return AiAction.Finish("Already in $name.")
      return AiAction.LaunchApp(name)
    }
    if ("wi-fi" in cmd || "wifi" in cmd) return AiAction.Wifi(!("off" in cmd))
    if ("screenshot" in cmd) return AiAction.Screenshot
    if ("scroll down" in cmd) return AiAction.Scroll("down")
    if ("scroll up" in cmd) return AiAction.Scroll("up")
    if ("swipe left" in cmd) return AiAction.Swipe("left")
    if ("swipe right" in cmd) return AiAction.Swipe("right")
    if (cmd.trim() in listOf("go back", "back", "press back")) return AiAction.Back
    if ("home" in cmd && "go home" in cmd) return AiAction.Home
    if ("search for" in cmd) {
      val q = cmd.substringAfter("search for").trim()
      val box = find("search", "query", "address")
      if (box != null && box.editable) return AiAction.Type(q, box.id)
      return AiAction.Finish("No search field visible for: $q. OBSERVED=${scr.elements.size} elements.")
    }
    if ("what is on the screen" in cmd || "what's on the screen" in cmd || "tell me what" in cmd || "describe" in cmd)
      return AiAction.Finish(scr.screenText.take(800).ifEmpty { "Screen has ${scr.elements.size} elements but no readable text." })
    if (cmd.startsWith("type ") || (("message" in cmd || "saying" in cmd) && ctx.history.none { it.startsWith("typed:") })) {
      val text = cmd.substringAfter("saying ").substringAfter("type ").trim().ifEmpty { return AiAction.Ask("What text should I type?") }
      val box = scr.elements.firstOrNull { it.editable } ?: find("message", "chat", "comment")
      if (box != null) return AiAction.Type(text, box.id)
      return AiAction.Ask("I don't see a text field. Open the conversation first, then tell me the message.")
    }
    val send = find("send")
    if (send != null && ctx.history.any { it.startsWith("typed:") } && ("send" in cmd || "message" in cmd))
      return AiAction.TapElement(send.id, "Send button matches requested send", 0.9)
    return AiAction.Ask("I see ${scr.elements.size} elements in ${scr.appName.ifEmpty { scr.packageName }}. What should I tap or type next for: ${ctx.command}")
  }
}

private fun openAiCompat(id: String, name: String, key: () -> String?, base: () -> String, model: () -> String, vision: Boolean) = object : AIProvider {
  override val id = id
  override val displayName = name
  override val supportsVision = vision
  override suspend fun nextAction(ctx: AgentContext): AiAction = withContext(Dispatchers.IO) {
    val k = key()
    if (k.isNullOrBlank()) return@withContext RuleBasedBrain().nextAction(ctx)
    val imageB64 = ctx.screenshotJpegB64
    val visionSent = vision && imageB64 != null
    try {
      val w = ctx.screen.displayW
      val h = ctx.screen.displayH
      val sys = "Phone agent. Output exactly ONE JSON action. Valid: tap_element{targetId,reason,confidence}, tap_coordinate{x,y,reason,confidence} (display pixels 0.." + w + " x 0.." + h + "; ONLY when an image is attached, else forbidden), long_press, double_tap, type{text,targetId?}, clear_text, paste, swipe{direction}, scroll{direction,amount}, drag{x1,y1,x2,y2}, back{}, home{}, recent_apps{}, launch_app{query}, switch_app{packageName}, open_notifications{}, open_settings{}, wifi{on}, screenshot{}, wait{ms}, copy{}, share{}, press_key{code:enter|delete|tab}, finish{message,success}, ask_user{question}. Prefer tap_element. Never passwords. Never code."
      val promptText = "GOAL: " + ctx.command + "\n" + ScreenSummarizer.toPrompt(ctx.screen) + "\nHISTORY: " + ctx.history.takeLast(8).joinToString(" | ").take(1500) + "\nVISION-IMAGE-ATTACHED: " + visionSent
      val body = buildJsonObject {
        put("model", model())
        putJsonArray("messages") {
          addJsonObject { put("role", "system"); put("content", sys) }
          addJsonObject {
            put("role", "user")
            if (visionSent) {
              putJsonArray("content") {
                addJsonObject { put("type", "text"); put("text", promptText.take(6000)) }
                addJsonObject {
                  put("type", "image_url")
                  putJsonObject("image_url") { put("url", "data:image/jpeg;base64,$imageB64") }
                }
              }
            } else {
              put("content", promptText.take(6000))
            }
          }
        }
      }
      val conn = java.net.URL(base().trimEnd('/') + "/chat/completions").openConnection() as java.net.HttpURLConnection
      conn.requestMethod = "POST"
      conn.setRequestProperty("Authorization", "Bearer $k")
      conn.setRequestProperty("Content-Type", "application/json")
      conn.doOutput = true; conn.connectTimeout = 25000; conn.readTimeout = 90000
      conn.outputStream.use { it.write(body.toString().toByteArray()) }
      val res = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
      val content = Json.parseToJsonElement(res).jsonObject["choices"]?.jsonArray?.getOrNull(0)
        ?.jsonObject?.get("message")?.jsonObject?.get("content")?.jsonPrimitive?.content ?: "{}"
      val a = content.indexOf('{'); val b = content.lastIndexOf('}')
      val parsed = parseAiAction(if (a >= 0 && b > a) content.substring(a, b + 1) else "{}")
      if (parsed is AiAction.TapCoordinate && !visionSent) return@withContext AiAction.Ask("Vision image was not attached, so I cannot tap coordinates. Describe which labelled element to tap.")
      parsed
    } catch (_: Exception) { RuleBasedBrain().nextAction(ctx) }
  }
}

fun buildProvider(providerId: String, key: () -> String?, base: () -> String, model: () -> String): AIProvider =
  when (providerId) {
    "gemini" -> openAiCompat("gemini", "Gemini (OpenAI-compat endpoint)", key, base, model, true)
    "anthropic" -> openAiCompat("anthropic", "Anthropic (OpenAI-compat endpoint)", key, base, model, true)
    "openrouter" -> openAiCompat("openrouter", "OpenRouter", key, base, model, true)
    "rule" -> RuleBasedBrain()
    else -> openAiCompat("openai", "OpenAI-compatible", key, base, model, true)
  }

typealias AIService = AIProvider
