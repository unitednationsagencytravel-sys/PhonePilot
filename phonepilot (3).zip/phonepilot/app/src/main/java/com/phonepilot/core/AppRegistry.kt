package com.phonepilot.core

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

data class AppEntry(val label: String, val packageName: String)

object AppRegistry {
  private var cache: List<AppEntry>? = null

  fun installed(ctx: Context, refresh: Boolean = false): List<AppEntry> {
    cache?.let { if (!refresh) return it }
    val pm = ctx.packageManager
    val out = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
      .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
      .distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    cache = out
    return out
  }

  fun find(ctx: Context, query: String): AppEntry? {
    val q = query.lowercase().trim().removePrefix("open ").trim()
    if (q.isEmpty()) return null
    val apps = installed(ctx)
    apps.firstOrNull { it.label.equals(q, true) }?.let { return it }
    apps.firstOrNull { it.packageName.equals(q, true) }?.let { return it }
    apps.firstOrNull { it.label.lowercase().contains(q) || q.contains(it.label.lowercase()) }?.let { return it }
    val nospace = q.replace(" ", "")
    apps.firstOrNull { it.packageName.lowercase().contains(nospace) }?.let { return it }
    return null
  }

  fun launch(ctx: Context, entry: AppEntry): Boolean {
    return try {
      val i = ctx.packageManager.getLaunchIntentForPackage(entry.packageName)
        ?: return false
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      ctx.startActivity(i)
      true
    } catch (_: Exception) { false }
  }

  fun labelFor(ctx: Context, pkg: String): String {
    return try {
      val pm = ctx.packageManager
      pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (_: PackageManager.NameNotFoundException) { pkg }
  }
}
