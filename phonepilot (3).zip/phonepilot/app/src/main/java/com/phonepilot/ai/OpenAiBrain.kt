package com.phonepilot.ai

class OpenAiBrain(
  val apiKey: () -> String?,
  val baseUrl: () -> String,
  val model: () -> String
) : AIProvider by openAiCompatShim(apiKey, baseUrl, model)

private fun openAiCompatShim(k: () -> String?, b: () -> String, m: () -> String): AIProvider =
  buildProvider("openai", k, b, m)
