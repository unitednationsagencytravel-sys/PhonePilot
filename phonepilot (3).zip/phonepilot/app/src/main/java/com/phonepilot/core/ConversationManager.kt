package com.phonepilot.core
data class Msg(val fromMe: Boolean, val text: String)
class ConversationManager {
  private val _m = mutableListOf<Msg>(); val messages: List<Msg> get() = _m.toList()
  fun add(m: Msg) { _m.add(m) }
  fun clear() { _m.clear() }
}
