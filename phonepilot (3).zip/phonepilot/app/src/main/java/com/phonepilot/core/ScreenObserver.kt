package com.phonepilot.core

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.phonepilot.PilotAccessibilityService
import com.phonepilot.ai.Bounds
import com.phonepilot.ai.ScreenState
import com.phonepilot.ai.UiElement

object ScreenObserver {
  fun snapshot(svc: PilotAccessibilityService): ScreenState {
    val root = svc.rootInActiveWindow
    val pkg = svc.currentPackage.ifEmpty { root?.packageName?.toString() ?: "" }
    val appName = try { AppRegistry.labelFor(svc, pkg) } catch (_: Exception) { pkg }
    val m = svc.resources.displayMetrics
    return snapshot(pkg, appName, root, m.widthPixels, m.heightPixels)
  }

  fun snapshot(pkg: String, appName: String, root: AccessibilityNodeInfo?, w: Int, h: Int): ScreenState {
    val els = mutableListOf<UiElement>()
    val texts = LinkedHashSet<String>()
    var idx = 0
    val r = Rect()
    fun walk(n: AccessibilityNodeInfo?, depth: Int) {
      if (n == null || depth > 10 || els.size >= 80) return
      try {
        if (!n.isVisibleToUser) {
          for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
          return
        }
        val rawText = (n.text?.toString() ?: "").trim()
        val rawDesc = (n.contentDescription?.toString() ?: "").trim()
        val cls = (n.className ?: "").toString()
        val isPass = n.isPassword
        val scrollable = n.isScrollable || n.actionList.any {
          it.id == AccessibilityNodeInfo.ACTION_SCROLL_FORWARD || it.id == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        val editable = cls.contains("EditText") || n.actionList.any { it.id == android.R.id.accessibilityActionSetText }
        if (!isPass) {
          if (rawText.isNotEmpty()) texts.add(rawText.take(80))
          else if (rawDesc.isNotEmpty()) texts.add(rawDesc.take(80))
        }
        val important = rawText.isNotEmpty() || rawDesc.isNotEmpty() || n.isClickable || editable || scrollable
        if (important) {
          try { n.getBoundsInScreen(r) } catch (_: Exception) { r.set(0, 0, 0, 0) }
          els.add(
            UiElement(
              id = "element_$idx",
              text = if (isPass) "" else rawText.take(80),
              contentDescription = if (isPass) "" else rawDesc.take(80),
              className = cls.take(80),
              clickable = n.isClickable,
              editable = editable,
              scrollable = scrollable,
              password = isPass,
              bounds = Bounds(r.left, r.top, r.right, r.bottom)
            )
          )
          idx++
        }
      } catch (_: Exception) { }
      for (i in 0 until (try { n.childCount } catch (_: Exception) { 0 })) {
        walk(try { n.getChild(i) } catch (_: Exception) { null }, depth + 1)
      }
    }
    walk(root, 0)
    val dedup = els.distinctBy { it.text + "|" + it.contentDescription + "|" + it.className + "|" + it.clickable }.take(80)
    val remapped = dedup.mapIndexed { i, e -> e.copy(id = "element_$i") }
    return ScreenState(pkg, appName, texts.joinToString(" | ").take(2500), remapped, System.currentTimeMillis(), w, h)
  }
}
