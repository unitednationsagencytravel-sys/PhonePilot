package com.phonepilot.core

import com.phonepilot.ai.AiAction
import com.phonepilot.ai.ScreenState

object ActionValidator {
  private val SENSITIVE = listOf("send", "delete", "uninstall", "purchase", "pay", "money", "transfer", "booking", "post", "publish", "account setting", "password change")
  private val AUTH_HINTS = listOf("enter pin", "enter password", "fingerprint", "biometric", "captcha", "verify it's you", "2-step")

  fun isAuthScreen(s: ScreenState): Boolean {
    val t = (s.screenText + " " + s.appName).lowercase()
    return AUTH_HINTS.any { it in t } || s.elements.any { it.password }
  }

  fun validate(a: AiAction, screen: ScreenState? = null, vision: Boolean = false): String? {
    when (a) {
      is AiAction.TapElement -> {
        if (a.targetId.isBlank()) return "tap_element needs targetId — re-observe, never guess."
        if (screen != null && screen.elements.none { it.id == a.targetId })
          return "Unknown ${a.targetId} — re-observe before acting."
      }
      is AiAction.TapCoordinate -> {
        if (!vision) return "tap_coordinate needs vision — fall back to tap_element."
        if (screen == null) return "No screen — cannot verify coordinate."
        if (a.x !in 0..screen.displayW || a.y !in 0..screen.displayH)
          return "Coordinate out of bounds — re-observe."
        if (a.confidence < 0.5) return "Confidence too low — ask user instead of tapping."
      }
      is AiAction.Type -> if (a.text.isEmpty()) return "type needs text."
      is AiAction.LaunchApp -> if (a.query.isBlank()) return "launch_app needs query."
      is AiAction.Swipe -> if (a.direction !in setOf("up", "down", "left", "right")) return "Bad swipe direction."
      is AiAction.Scroll -> if (a.direction !in setOf("up", "down", "left", "right")) return "Bad scroll direction."
      is AiAction.Drag -> {
        if (screen != null && (listOf(a.x1, a.x2).any { it !in 0..screen.displayW } || listOf(a.y1, a.y2).any { it !in 0..screen.displayH }))
          return "Drag out of bounds."
      }
      is AiAction.PressKey -> if (a.code !in setOf("enter", "delete", "tab", "search")) return "Unsupported key."
      else -> {}
    }
    return null
  }

  fun needsConfirmation(cmd: String, a: AiAction, confirmEnabled: Boolean): Boolean {
    if (!confirmEnabled) return false
    if (a is AiAction.Finish || a is AiAction.Ask || a is AiAction.Wait || a is AiAction.Screenshot) return false
    val c = cmd.lowercase()
    if (SENSITIVE.any { it in c }) return true
    if (a is AiAction.TapElement) {
      val t = a.targetId.lowercase()
      if (SENSITIVE.any { it in t }) return true
    }
    return false
  }
}
