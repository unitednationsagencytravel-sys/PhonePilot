package com.phonepilot.core

import com.phonepilot.ai.ScreenState

class ScreenHistory(private val max: Int = 3) {
  private val deque = ArrayDeque<ScreenState>()
  var lastAction: String = ""
  var lastResult: String = ""
  var lastDecision: String = ""
  fun push(s: ScreenState) {
    deque.addLast(s)
    while (deque.size > max) deque.removeFirst()
  }
  fun previous(): ScreenState? = if (deque.size >= 2) deque[deque.size - 2] else null
  fun current(): ScreenState? = deque.lastOrNull()
  fun changedSincePrevious(s: ScreenState): Boolean {
    val p = previous() ?: return true
    return p.packageName != s.packageName || p.screenText != s.screenText || p.elements.size != s.elements.size
  }
}
