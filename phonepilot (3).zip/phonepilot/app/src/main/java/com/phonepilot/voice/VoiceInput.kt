package com.phonepilot.voice
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.*
import kotlinx.coroutines.flow.*

class VoiceInput(ctx: Context) {
  private val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
  private val _text = MutableStateFlow(""); val text: StateFlow<String> = _text
  fun listen(lang: String = "en-US", onResult: (String) -> Unit) {
    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
    }
    rec.setRecognitionListener(object : RecognitionListener {
      override fun onResults(r: Bundle?) { val s = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""; _text.value = s; onResult(s) }
      override fun onError(e: Int) {}
      override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
    })
    rec.startListening(i)
  }
  fun stop() { try { rec.stopListening() } catch (_: Exception) {} }
}
