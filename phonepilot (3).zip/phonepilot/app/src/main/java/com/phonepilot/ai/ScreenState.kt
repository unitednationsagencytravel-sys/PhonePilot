package com.phonepilot.ai

data class Bounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
  val cx: Int get() = (left + right) / 2
  val cy: Int get() = (top + bottom) / 2
  fun valid(w: Int, h: Int) = left >= 0 && top >= 0 && right <= w && bottom <= h && right > left && bottom > top
}

data class UiElement(
  val id: String,
  val text: String,
  val contentDescription: String,
  val className: String,
  val clickable: Boolean,
  val editable: Boolean,
  val scrollable: Boolean,
  val password: Boolean,
  val bounds: Bounds
)

data class ScreenState(
  val packageName: String,
  val appName: String,
  val screenText: String,
  val elements: List<UiElement>,
  val timestamp: Long = System.currentTimeMillis(),
  val displayW: Int = 1080,
  val displayH: Int = 2400
)

data class AgentContext(
  val command: String,
  val screen: ScreenState,
  val history: List<String>,
  val hasVision: Boolean,
  val attempt: Int = 0,
  val screenshotJpegB64: String? = null
)

object ScreenSummarizer {
  fun toPrompt(screen: ScreenState, maxEls: Int = 40): String {
    val sb = StringBuilder()
    sb.append("APP: ").append(screen.appName.ifEmpty { screen.packageName }).append(" (").append(screen.packageName).append(")\n")
    sb.append("SCREEN-TEXT: ").append(screen.screenText.take(1200)).append("\nELEMENTS:\n")
    screen.elements.take(maxEls).forEach { e ->
      val label = e.text.ifEmpty { e.contentDescription }.take(50)
      sb.append(e.id).append(" [").append(e.className.substringAfterLast('.').take(18)).append("]")
      if (e.clickable) sb.append("(tap)")
      if (e.editable) sb.append("(edit)")
      if (e.scrollable) sb.append("(scroll)")
      sb.append(" \"").append(label).append("\"")
      sb.append(" @").append(e.bounds.cx).append(",").append(e.bounds.cy).append("\n")
    }
    return sb.toString()
  }
}
