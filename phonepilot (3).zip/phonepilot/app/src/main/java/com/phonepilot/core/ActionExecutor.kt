package com.phonepilot.core

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.phonepilot.PilotAccessibilityService
import com.phonepilot.ai.AiAction
import com.phonepilot.ai.ScreenState
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class ActionResult(val ok: Boolean, val message: String)

object ActionExecutor {

  suspend fun execute(svc: PilotAccessibilityService, screen: ScreenState, a: AiAction): ActionResult {
    return when (a) {
      is AiAction.TapElement -> tapElement(svc, screen, a.targetId)
      is AiAction.TapCoordinate -> gestureTap(svc, a.x.toFloat(), a.y.toFloat(), 80, "tapped ${a.x},${a.y}")
      is AiAction.LongPress -> {
        val p = resolvePoint(svc, screen, a.targetId, a.x, a.y) ?: return ActionResult(false, "long-press target gone")
        gestureTap(svc, p.first.toFloat(), p.second.toFloat(), 700, "long-pressed")
      }
      is AiAction.DoubleTap -> {
        val p = resolvePoint(svc, screen, a.targetId, a.x, a.y) ?: return ActionResult(false, "double-tap target gone")
        gestureTap(svc, p.first.toFloat(), p.second.toFloat(), 60, "double-tap-1")
        gestureTap(svc, p.first.toFloat(), p.second.toFloat(), 60, "double-tapped")
      }
      is AiAction.Type -> typeText(svc, screen, a.text, a.targetId)
      is AiAction.ClearText -> clearText(svc, screen, a.targetId)
      is AiAction.Paste -> {
        val box = nodeFor(svc, screen, a.targetId) ?: return ActionResult(false, "no editable field for paste")
        box.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        ActionResult(true, "pasted")
      }
      is AiAction.Swipe -> {
        val m = svc.resources.displayMetrics; val w = m.widthPixels; val h = m.heightPixels
        val pts = if (a.x1 != null && a.y1 != null && a.x2 != null && a.y2 != null)
          floatArrayOf(a.x1.toFloat(), a.y1.toFloat(), a.x2.toFloat(), a.y2.toFloat())
        else when (a.direction) {
          "up" -> floatArrayOf(w / 2f, h * 3 / 4f, w / 2f, h / 4f)
          "down" -> floatArrayOf(w / 2f, h / 4f, w / 2f, h * 3 / 4f)
          "left" -> floatArrayOf(w * 3 / 4f, h / 2f, w / 4f, h / 2f)
          else -> floatArrayOf(w / 4f, h / 2f, w * 3 / 4f, h / 2f)
        }
        gestureLine(svc, pts[0], pts[1], pts[2], pts[3], 300, "swiped ${a.direction}")
      }
      is AiAction.Scroll -> {
        val node = a.targetId?.let { nodeFor(svc, screen, it) }
        if (node != null) {
          val fwd = a.direction in setOf("down", "right")
          val ok = node.performAction(if (fwd) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
          ActionResult(ok, if (ok) "scrolled ${a.direction}" else "scroll failed")
        } else {
          val m = svc.resources.displayMetrics; val w = m.widthPixels; val h = m.heightPixels
          val amt = a.amount.coerceIn(200, h - 100)
          val (y1, y2) = if (a.direction == "up") (h / 4f to h * 3 / 4f) else (h * 3 / 4f to (h * 3 / 4f - amt).coerceAtLeast(h / 4f))
          gestureLine(svc, w / 2f, y1, w / 2f, y2, 350, "scrolled ${a.direction}")
        }
      }
      is AiAction.Drag -> gestureLine(svc, a.x1.toFloat(), a.y1.toFloat(), a.x2.toFloat(), a.y2.toFloat(), 500, "dragged")
      is AiAction.Back -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); ActionResult(true, "pressed back") }
      is AiAction.Home -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); ActionResult(true, "pressed home") }
      is AiAction.RecentApps -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); ActionResult(true, "opened recents") }
      is AiAction.LaunchApp -> {
        val entry = AppRegistry.find(svc, a.query)
          ?: return ActionResult(false, "app not installed: ${a.query}")
        if (!AppRegistry.launch(svc, entry)) return ActionResult(false, "launch failed: ${entry.label}")
        ActionResult(true, "launched ${entry.label}")
      }
      is AiAction.SwitchApp -> {
        val i = svc.packageManager.getLaunchIntentForPackage(a.packageName)
          ?: return ActionResult(false, "cannot switch: ${a.packageName}")
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        svc.startActivity(i)
        ActionResult(true, "switched to ${a.packageName}")
      }
      is AiAction.OpenNotifications -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); ActionResult(true, "opened notifications") }
      is AiAction.OpenSettings -> {
        svc.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult(true, "opened settings")
      }
      is AiAction.Wifi -> { setWifi(svc, a.on); ActionResult(true, "wifi ${if (a.on) "on" else "off"} (verify in Settings)") }
      is AiAction.Screenshot -> {
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        ActionResult(true, "took screenshot")
      }
      is AiAction.Wait -> { delay(a.ms.coerceIn(200, 8000).toLong()); ActionResult(true, "waited") }
      is AiAction.Copy -> { copyFocused(svc); ActionResult(true, "copied") }
      is AiAction.Share -> { shareText(svc, screen); ActionResult(true, "shared") }
      is AiAction.PressKey -> pressKey(svc, screen, a.code)
      is AiAction.Finish -> ActionResult(true, "finished: ${a.message}")
      is AiAction.Ask -> ActionResult(true, "asked: ${a.question}")
    }
  }

  private fun nodeFor(svc: PilotAccessibilityService, screen: ScreenState, targetId: String?): AccessibilityNodeInfo? {
    val root = svc.rootInActiveWindow ?: return null
    if (targetId == null) return firstEditable(root)
    val el = screen.elements.firstOrNull { it.id == targetId } ?: return null
    val key = el.text.ifEmpty { el.contentDescription }
    if (key.isNotEmpty()) {
      val hit = root.findAccessibilityNodeInfosByText(key).firstOrNull()
      if (hit != null) return hit
    }
    return firstEditable(root)
  }

  private fun resolvePoint(svc: PilotAccessibilityService, screen: ScreenState, id: String?, x: Int?, y: Int?): Pair<Int, Int>? {
    if (x != null && y != null && x >= 0 && y >= 0) return x to y
    val el = screen.elements.firstOrNull { it.id == id } ?: return null
    val m = svc.resources.displayMetrics
    val cx = el.bounds.cx.coerceIn(0, m.widthPixels - 1)
    val cy = el.bounds.cy.coerceIn(0, m.heightPixels - 1)
    if (el.bounds.right <= el.bounds.left || el.bounds.bottom <= el.bounds.top) return null
    return cx to cy
  }

  private fun tapElement(svc: PilotAccessibilityService, screen: ScreenState, targetId: String): ActionResult {
    val node = nodeFor(svc, screen, targetId)
    if (node == null) {
      val el = screen.elements.firstOrNull { it.id == targetId }
      if (el != null && el.bounds.valid(svc.resources.displayMetrics.widthPixels, svc.resources.displayMetrics.heightPixels)) {
        var c: AccessibilityNodeInfo? = svc.rootInActiveWindow ?: return ActionResult(false, "no screen")
        return ActionResult(false, "NEEDS_COORD:${el.bounds.cx},${el.bounds.cy}")
      }
      return ActionResult(false, "element not found: $targetId")
    }
    var c: AccessibilityNodeInfo? = node
    while (c != null && !c.isClickable) c = c.parent
    val ok = (c ?: node).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    return ActionResult(ok, if (ok) "tapped $targetId" else "tap failed: $targetId")
  }

  private fun typeText(svc: PilotAccessibilityService, screen: ScreenState, text: String, targetId: String?): ActionResult {
    val box = nodeFor(svc, screen, targetId) ?: return ActionResult(false, "no editable field")
    try { box.performAction(AccessibilityNodeInfo.ACTION_FOCUS) } catch (_: Exception) {}
    val b = Bundle()
    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
    val ok = box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    if (ok) {
      val check = ((box.text?.toString() ?: "") == text)
      return ActionResult(true, "typed: $text" + if (!check) " (unverified)" else "")
    }
    return ActionResult(false, "type failed")
  }

  private fun clearText(svc: PilotAccessibilityService, screen: ScreenState, targetId: String?): ActionResult {
    val box = nodeFor(svc, screen, targetId) ?: return ActionResult(false, "no editable field")
    val b = Bundle()
    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
    val ok = box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    return ActionResult(ok, if (ok) "cleared text" else "clear failed")
  }

  private fun pressKey(svc: PilotAccessibilityService, screen: ScreenState, code: String): ActionResult {
    val root = svc.rootInActiveWindow ?: return ActionResult(false, "no screen")
    val focus = firstEditable(root) ?: root
    when (code) {
      "enter", "search" -> {
        val ok = focus.performAction(AccessibilityNodeInfo.ACTION_IME_ENTER)
        return ActionResult(ok, if (ok) "pressed $code" else "enter failed")
      }
      else -> return ActionResult(false, "key $code not permitted without IME — use back/home instead")
    }
  }

  private fun copyFocused(svc: PilotAccessibilityService) {
    try {
      val root = svc.rootInActiveWindow ?: return
      val t = firstText(root) ?: return
      val cm = svc.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
      cm.setPrimaryClip(ClipData.newPlainText("pilot", t))
    } catch (_: Exception) {}
  }

  private fun shareText(svc: PilotAccessibilityService, screen: ScreenState) {
    try {
      val i = Intent(Intent.ACTION_SEND).setType("text/plain")
        .putExtra(Intent.EXTRA_TEXT, screen.screenText.take(1000)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      svc.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
  }

  private fun firstEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
    if (n == null) return null
    try {
      if (n.className?.toString()?.contains("EditText") == true) return n
      for (i in 0 until n.childCount) {
        val f = firstEditable(n.getChild(i))
        if (f != null) return f
      }
    } catch (_: Exception) {}
    return null
  }

  private fun firstText(n: AccessibilityNodeInfo?): String? {
    if (n == null) return null
    val t = n.text?.toString()
    if (!t.isNullOrBlank()) return t
    for (i in 0 until n.childCount) {
      val f = firstText(n.getChild(i))
      if (!f.isNullOrBlank()) return f
    }
    return null
  }

  private suspend fun gestureTap(svc: PilotAccessibilityService, x: Float, y: Float, dur: Long, msg: String): ActionResult {
    val path = Path().apply { moveTo(x, y); lineTo(x + 1, y + 1) }
    return dispatch(svc, path, dur, msg)
  }

  private suspend fun gestureLine(svc: PilotAccessibilityService, x1: Float, y1: Float, x2: Float, y2: Float, dur: Long, msg: String): ActionResult {
    val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
    return dispatch(svc, path, dur, msg)
  }

  private suspend fun dispatch(svc: PilotAccessibilityService, path: Path, dur: Long, msg: String): ActionResult {
    val g = GestureDescription.Builder()
      .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
    return suspendCancellableCoroutine { cont ->
      try {
        svc.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
          override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(ActionResult(true, msg)) }
          override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(ActionResult(false, "gesture cancelled")) }
        }, null)
      } catch (_: Exception) { if (cont.isActive) cont.resume(ActionResult(false, "gesture failed")) }
    }
  }

  @Suppress("DEPRECATION")
  private fun setWifi(svc: PilotAccessibilityService, on: Boolean) {
    try {
      (svc.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = on
    } catch (_: Exception) {
      svc.startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
  }
}
