package com.phonepilot.vision

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

data class ScreenImage(val bitmap: Bitmap, val timestamp: Long = System.currentTimeMillis())

object ScreenshotManager {
  private var projection: MediaProjection? = null
  var hasPermission: Boolean = false
    private set
  var lastCaptureOk: Boolean = false
  var lastCaptureAt: Long = 0L
  var lastError: String = ""

  fun createRequestIntent(ctx: Context): Intent {
    val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    return mpm.createScreenCaptureIntent()
  }

  fun onPermissionResult(ctx: Context, resultCode: Int, data: Intent?) {
    if (resultCode == Activity.RESULT_OK && data != null) {
      try {
        val svc = ScreenCaptureService.startIntent(ctx, resultCode, data)
        if (Build.VERSION.SDK_INT >= 26) {
          try { ContextCompat.startForegroundService(ctx, svc) } catch (_: Exception) { ctx.startService(svc) }
        } else {
          ctx.startService(svc)
        }
        hasPermission = true
        lastError = ""
      } catch (e: Exception) {
        hasPermission = false
        lastError = e.message ?: "consent failed"
      }
    } else {
      hasPermission = false
      lastError = "user denied screen capture"
    }
  }

  internal fun attachProjection(proj: MediaProjection) {
    try { projection?.stop() } catch (_: Exception) {}
    projection = proj
    hasPermission = true
    lastError = ""
    try {
      proj.registerCallback(object : MediaProjection.Callback() {
        override fun onStop() { hasPermission = false }
      }, null)
    } catch (_: Exception) {}
  }

  internal fun detachProjection() {
    try { projection?.stop() } catch (_: Exception) {}
    projection = null
    hasPermission = false
  }

  fun revoke(ctx: Context) {
    try { ctx.startService(Intent(ctx, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP)) } catch (_: Exception) {}
    detachProjection()
  }

  suspend fun capture(ctx: Context, w: Int = 540, h: Int = 960): ScreenImage? = withContext(Dispatchers.IO) {
    val proj = projection
    if (proj == null) { lastCaptureOk = false; lastError = "no MediaProjection — grant capture first"; return@withContext null }
    var vd: VirtualDisplay? = null
    var reader: ImageReader? = null
    val thread = HandlerThread("pp-shot").apply { start() }
    try {
      reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
      vd = proj.createVirtualDisplay("pp", w, h, ctx.resources.displayMetrics.densityDpi,
        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, Handler(thread.looper))
      Thread.sleep(450)
      val img = reader.acquireLatestImage()
      if (img == null) { lastCaptureOk = false; lastError = "empty frame"; return@withContext null }
      try {
        val plane: ByteBuffer = img.planes[0].buffer
        val rowStride = img.planes[0].rowStride
        val pxStride = img.planes[0].pixelStride
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val row = ByteArray(rowStride)
        for (y in 0 until h) {
          plane.position(y * rowStride)
          plane.get(row, 0, rowStride)
          for (x in 0 until w) {
            val o = x * pxStride
            bmp.setPixel(x, y, ((row[o + 3].toInt() and 0xFF) shl 24) or ((row[o + 2].toInt() and 0xFF) shl 16) or ((row[o + 1].toInt() and 0xFF) shl 8) or (row[o].toInt() and 0xFF))
          }
        }
        lastCaptureOk = true
        lastCaptureAt = System.currentTimeMillis()
        lastError = ""
        ScreenImage(bmp)
      } finally { img.close() }
    } catch (e: Exception) { lastCaptureOk = false; lastError = e.message ?: "capture failed"; null }
    finally {
      try { vd?.release() } catch (_: Exception) {}
      try { reader?.close() } catch (_: Exception) {}
      thread.quitSafely()
    }
  }

  suspend fun captureJpegB64(ctx: Context): String? {
    val shot = capture(ctx) ?: return null
    return try {
      val b64 = ImageCodec.toJpegB64(shot.bitmap)
      try { shot.bitmap.recycle() } catch (_: Exception) {}
      b64
    } catch (e: Exception) { lastError = e.message ?: "encode failed"; null }
  }
}
