# PhonePilot repair — what changed (existing project, not rebuilt)

## FINAL PASS repairs (this session)
- REAL vision pipeline: `AgentContext.screenshotJpegB64` → `openAiCompat` sends actual `image_url: data:image/jpeg;base64,…` multimodal content ONLY when an image was captured; `tap_coordinate` without an attached image is rejected and converted to an ask. Rule brain declares no vision and never receives images.
- Vision gating in `TaskManager`: captures (540px JPEG~60) only when a11y insufficient (0 tappable-labelled elements, or grounding failure), max every 2 steps, never stored in history (flag only). Debug tab shows `image-sent` vs `a11y-only` + provider id.
- MediaProjection done right: new `ScreenCaptureService` foreground service (`mediaProjection` type, notification channel, START_STICKY, consent via `startForegroundService`, clean stop/revoke/taskRemoved, single VirtualDisplay per capture with guaranteed release). Manifest declares the service; minSdk 29.
- Build fixed: root adds `kotlin.plugin.compose` 2.0.20 and drops unused ksp; app applies the compose plugin and drops incompatible `kotlinCompilerExtensionVersion = 1.5.14`. Kotlin 2.0.20 + AGP 8.5.2 + BOM 2024.10.00 is coherent.
- All settings live: `maxSteps` (3–60 enforced in loop), provider/model/endpoint (recreates brain), confirm gate, debug toggle (fills Debug tab), voice language (passed to recognizer). API key field masked; key sent only to configured endpoint.

## Previously broken
- `UiElement` had no bounds/contentDescription/scrollable/appName; AI got `screenText.take(2000)` + 60 text-only elements — coordinates, scrollables, and element IDs were discarded. `tap_coordinate` was forbidden by the system prompt.
- Screenshot = `GLOBAL_ACTION_TAKE_SCREENSHOT` only (saves to gallery, never returns image data). No MediaProjection, no vision path, no capability flag — model was told "never passwords/coordinates" with no vision fallback.
- Actions: click-by-text, type, swipe-up/down, back, launch-by-hardcoded-map (`guessPackage`: 6 apps), web-search intent, wifi toggle. No long-press/double-tap/clear/paste/drag/home/recents/notifications/copy/share/press-key. No coordinate path.
- `TaskManager`: fixed `repeat(25)`, no before/after compare, no verification ("launched" claimed without checking package), `stuck` counter only, confirm gate deadlocked (`while pending != null` with no deny path wired), STOP only cancelled the job (a gesture in flight still completed).
- `SettingsManager.Cfg(key,base,model,confirm)` — one hardcoded OpenAI endpoint, no provider choice, no vision flag, no debug toggle.
- No `AppRegistry` (hardcoded map primary), no `ScreenHistory`, no summarizer limits documented, no Debug screen, no POCO/Xiaomi setup.

## What changed (same architecture, same file names where possible)
- `ai/ScreenState.kt` (new): `Bounds`, full `UiElement(id,text,contentDescription,className,clickable,editable,scrollable,password,bounds)`, `ScreenState(pkg,appName,screenText,elements,timestamp,displayW/H)`, `ScreenSummarizer.toPrompt()` (40 elements max, invisible/dupes removed, `id [Class](tap/edit/scroll) "label" @x,y`).
- `core/ScreenObserver.kt`: real bounds via `getBoundsInScreen`, `isVisibleToUser` filter, scrollable detection, password redaction, depth≤10 / 80 elements, stable `element_N` IDs. `snapshot(svc)` overload feeds the live service.
- `PilotAccessibilityService.kt`: holds `live: StateFlow<ScreenState?>`, pushes debounced (900ms) snapshots on every event + `pushNow()`, plus guarded `takeScreenshotApi30()` (API 30+ system screenshot, graceful false below).
- `ai/AiAction.kt`: strict schema — `tap_element{targetId,reason,confidence}`, `tap_coordinate{x,y,reason,confidence}`, `long_press`, `double_tap`, `type`, `clear_text`, `paste`, `swipe`, `scroll{direction,amount}`, `drag`, `back/home/recent_apps`, `launch_app{query}`, `switch_app`, `open_notifications/settings`, `wifi`, `screenshot`, `wait`, `copy/share`, `press_key(enter|delete|tab|search only)`, `finish`, `ask_user`. `parseAiAction` accepts legacy `click/launch` keys.
- `core/ActionValidator.kt`: schema checks, coordinate-in-bounds + confidence≥0.5 + vision-required, unknown-targetId rejection, `isAuthScreen()` (PIN/biometric/CAPTCHA/password → pause and hand to user), configurable sensitive gate.
- `core/ActionExecutor.kt`: all actions via Accessibility/gestures; element resolution by text→node with `NEEDS_COORD` fallback signal; gestures via `dispatchGesture` (tap/long/double/swipe/scroll/drag); `press_key` limited to IME-enter (documented); wifi falls back to Settings panel on Android 10+ restriction.
- `core/AppRegistry.kt` (new): dynamic launcher discovery via `PackageManager`, fuzzy match (exact label → package → contains), `guessPackage` demoted to last-resort hint. "Open Discord/Telegram/…" works with zero hardcoding.
- `vision/ScreenshotManager.kt` (new): real MediaProjection pipeline (permission intent → VirtualDisplay + ImageReader → Bitmap). `hasPermission` flag = vision availability. Accessibility screenshot kept as save-to-gallery action; vision images are never sent when provider lacks support.
- `ai/AIProvider.kt` (new, `AIService` = typealias): `AIProvider{id,displayName,supportsVision,nextAction}`; `RuleBasedBrain` (offline, no vision, uses real ScreenState); `buildProvider("openai|gemini|anthropic|openrouter|rule")` — all OpenAI-compat POSTs, key from Settings only. `AIService.kt` slimmed to `guessPackage` helper; `OpenAiBrain` kept as delegating shim so old imports compile.
- `core/TaskManager.kt`: true loop OBSERVE→PLAN→VALIDATE→EXECUTE-ONE→WAIT→OBSERVE→COMPARE; `ScreenHistory(3)`; `verify()` (launch checks active package, type checks visible text, else screen-diff; unverified results labelled, never claimed); `recoverHint()` + ≤5-failure stop + ask-user; atomic STOP flag checked before/after every suspend;_STEP limit from settings.
- `core/SettingsManager.kt`: `Cfg(provider,key,base,model,confirm,debug,maxSteps)` + per-provider default bases + provider list. Nothing hard-coded; key sent only to configured endpoint.
- `MainActivity.kt`: same 3 areas + Debug tab; provider dropdown, vision/screenshot permission launcher, max-steps, debug toggle; STOP full-width + atomic; confirm dialog wired to `confirmAction(ok)`; voice (`VoiceInput.listen`) feeds identical `tm.run()` path as typing.
- `AndroidManifest.xml`: added `FOREGROUND_SERVICE` + `MEDIA_PROJECTION` foreground-service permissions (MediaProjection requirement, API 34), `configChanges` on activity. No root, no ADB, no extra dangerous permissions.
- `SetupScreen`: POCO/Xiaomi checklist (Autostart ON, Battery → No restrictions, Notifications ON, lock in Recents, MIUI popup permission).

## How Accessibility works
Service (`flagReportViewIds|flagRetrieveInteractiveWindows|flagIncludeNotImportantViews`, `canPerformGestures|canTakeScreenshot|canRetrieveWindowContent`) receives `typeWindowStateChanged|typeWindowContentChanged`. Each event updates `currentPackage` and pushes a debounced `ScreenObserver.snapshot()` (tree walk → visible-only, redacted, bounded elements) into `live`. `TaskManager` snapshots fresh before AND after every action — never trusts a stale tree.

## How screenshot/vision works
Setup → "Grant screen capture" → system MediaProjection consent → `ScreenshotManager.projection`. Captures happen ONLY when a11y text is insufficient (icon-only button) AND provider `supportsVision` AND permission granted — else the agent says vision is unavailable and asks the user. Images are Bitmaps in memory (720×1280 VirtualDisplay), never stored unlimited; history keeps ScreenStates (text), not screenshots.

## How the AI receives ScreenState
`AgentContext(command, screen: ScreenState, history[≤8], hasVision, attempt)` → `ScreenSummarizer.toPrompt()` (app + package + 1200-char text + 40 elements with bounds centers). Rule brain reads the struct directly; network providers get the same string as the user message with a system prompt mandating single-JSON actions and `tap_element` preference.

## How actions are validated
`ActionValidator.validate(action, screen, vision)` runs BEFORE every execution; failures are fed back as history ("rejected: …") and count toward the 5-failure stop. Coordinates need vision + in-bounds + confidence. Auth screens hard-pause. Sensitive actions (send/delete/uninstall/pay/post/booking/…) need the confirm dialog when enabled.

## How app discovery works
`AppRegistry.installed()` caches launcher activities once; `find(query)` fuzzy-matches; `launch(entry)` uses the real launch intent. Test "Open Discord" → finds `com.discord` dynamically → `verify()` confirms `after.packageName/appName` matches.

## Known Android limitations (documented, not faked)
- `WifiManager.isWifiEnabled=` is deprecated/blocked on Android 10+ for third-party apps → falls back to opening Wi-Fi Settings for the user.
- `takeScreenshot()` API exists only on API 30+ and still saves via SystemUI, not to the agent — vision uses MediaProjection instead.
- No password/PIN/biometric/CAPTCHA bypass possible — agent pauses and hands over.
- Canvas/WebGL games exposing no nodes and no vision → reported as uncontrollable, never random-tapped.
- `press_key` cannot inject arbitrary keycodes via Accessibility — only IME-enter/delete/tab/search on the focused field; home/back/recents/notifications use the sanctioned global actions.
- Background execution on MIUI/HyperOS is killed aggressively — Autostart + No-restrictions + locked task required (Setup tab lists exact paths).

## Build / POCO F3 install / first test
Build: copy `phonepilot/` to PC → Android Studio Hedgehog+ (JDK 17, SDK 34) → Gradle sync → `./gradlew :app:assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`. Coherent config: Kotlin 2.0.20 + `kotlin.plugin.compose` 2.0.20 (no `kotlinCompilerExtensionVersion`), AGP 8.5.2, compose BOM 2024.10.00, minSdk 29 / target+compile 34. Install: `adb install app-debug.apk` or tap APK (allow unknown apps). Permissions to grant: Notifications, Microphone (voice), Accessibility → PhonePilot ON, Screen capture (optional vision), Wi-Fi change (or manual Settings). First test: AI tab → provider `Offline rules`, Save → Chat → send `Open Settings.` → expect `Opening Settings… → Waiting for UI… → Done: verified` and `currentPackage= com.android.settings` in Debug tab.
