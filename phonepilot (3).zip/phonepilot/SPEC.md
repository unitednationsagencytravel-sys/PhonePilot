# PhonePilot SPEC

## Agent loop
USER COMMAND → UNDERSTAND INTENT → OBSERVE SCREEN → PLAN NEXT ACTION → EXECUTE ONE ACTION → OBSERVE AGAIN → VERIFY → CONTINUE/FINISH.
Never blind-batch taps. Re-observe after every action.

## AI I/O
Input: {command, packageName, uiElements[], screenText, history[]}. Output: single JSON action:
{"action":"click","target":"Send"} | {"action":"type","text":"..."} | {"action":"swipe","direction":"up|down|left|right"} | {"action":"scroll","direction":"..."} | {"action":"back"} | {"action":"launch","package":"com.whatsapp"} | {"action":"search","query":"..."} | {"action":"wait","ms":800} | {"action":"finish","message":"..."} | {"action":"ask","question":"..."} 
Validator allowlist: click,type,scroll,swipe,back,launch,search,open_settings,wifi,screenshot,wait,finish,ask. Blocks: coordinates-only taps, >1 action per step, sensitive actions without confirmation.

## Safety
Sensitive = send/delete/uninstall/purchase/money/account-change/post-public/booking. Requires user confirm dialog. Global STOP cancels TaskManager job + executor. Secrets never sent to AI (fields flagged password redacted by ScreenObserver).

## Error handling
No element → re-observe (up to 2x) → try alternate interpretation → ask user → safe stop.
